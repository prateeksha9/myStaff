import Pagination from './Pagination';
import Posts from './Posts';
import PostsList from './PostsList';
import Heading from './Heading';
import Header from './Header';

export { Pagination, Posts, PostsList, Heading, Header };
