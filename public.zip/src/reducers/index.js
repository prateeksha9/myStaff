import { combineReducers } from 'redux';
import posts from './posts';

//  combine both these reducers
export default combineReducers({
  posts,
});
