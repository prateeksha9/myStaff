export const UPDATE_POSTS = 'UPDATE_POSTS';
export const DELETE_POST = 'DELETE_POST';
export const EDIT_POST = 'EDIT_POST';
export const TO_BE_DELETED = 'TO_BE_DELETED';
export const DELETE_MULTIPLE = 'DELETE_MULTIPLE';
export const SEARCH_FOR = 'SEARCH_FOR';
